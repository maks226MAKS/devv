from django.db import models

from django.contrib.auth.models import User


class ShippingAddress(models.Model):

    first_name = models.CharField(max_length=64)

    last_name = models.CharField(max_length=64)

    email = models.EmailField(max_length=256)

    address = models.CharField(max_length=256)

    city = models.CharField(max_length=255)

    zipcode = models.CharField(max_length=255, null=True, blank=True)

    # Authenticated

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)

    class Meta:

        verbose_name_plural = 'Адреса для відправлення'

    def __str__(self):

        return 'Торгова адреса - ' + str(self.id)










