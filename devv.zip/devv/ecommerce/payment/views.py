from django.shortcuts import render, redirect

from .forms import ShippingForm

from . models import ShippingAddress

from django.http import JsonResponse






# Shipping views

def manage_shipping(request):

    form = ShippingForm()

    if request.method == 'POST':

        form = ShippingForm(request.POST)

        if form.is_valid():

            shipping_user = form.save()

            shipping_user.user = request.user

            shipping_user.save()

            return redirect('dashboard')


    context = {'form':form}

    return render(request, 'payment/manage-shipping.html', context=context)

def payment_success(request):

    for key in list(request.session.keys()):

        if key == 'session_key':

            del request.session[key]


    return render(request, 'payment/payment-success.html')


def payment_failed(request):

    return render(request, 'payment/payment-failed.html')

def checkout(request):

    if request.user.is_authenticated:

        try:

            shipping_address = ShippingAddress.objects.get(user=request.user.id)

            context = {'купити': shipping_address}

            return render(request, 'payment/checkout.html', context=context)

        except:

            return render(request, 'payment/checkout.html')

    else:

        return render(request, 'payment/checkout.html')

def complete_order(request):

    if request.POST.get('action') == 'post':

        name = request.POST.get('name')
        name1 = request.POST.get('name1')
        email = request.POST.get('email')
        address = request.POST.get('address')
        city = request.POST.get('city')
        zipcode = request.POST.get('zipcode')

        if request.user.is_authenticated:

            order = ShippingAddress(first_name=name, last_name=name1, email=email, address=address, city=city, zipcode=zipcode,
                                    user=request.user)
            order.save()

            return JsonResponse({'success': True})

    return render(request, 'complete-order.html')


















